import React from 'react';
    import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
    import { Button } from '@/components/ui/button';
    import { Zap, Users, CheckSquare, Gamepad2 } from 'lucide-react';
    import { useTranslation } from 'react-i18next';
    import { motion } from 'framer-motion';

    const WelcomeModal = ({ isOpen, setIsOpen }) => {
      const { t, i18n } = useTranslation(['modals', 'common']);

      const greetings = {
        en: "Hello",
        ar: "مرحباً",
        fr: "Bonjour",
        ru: "Привет",
        zh: "你好",
        hi: "नमस्ते",
        pt: "Olá",
        es: "Hola",
        fa: "سلام"
      };
      const currentGreeting = greetings[i18n.language] || greetings.en;

      return (
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
          <DialogContent className="bg-gradient-to-br from-gray-900 via-purple-950 to-gray-900 text-white border-purple-500/50 shadow-2xl rounded-xl">
            <DialogHeader>
              <DialogTitle className="text-3xl font-bold text-center text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 via-pink-500 to-purple-500 mb-4">
                {currentGreeting}! {t('welcomeModal.title')}
              </DialogTitle>
              <DialogDescription className="text-purple-300 text-center text-md mb-6">
                {t('welcomeModal.description')}
              </DialogDescription>
            </DialogHeader>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="space-y-4 text-sm"
            >
              <div className="flex items-start p-3 bg-purple-500/10 rounded-lg border border-purple-500/30">
                <Zap className="w-8 h-8 text-yellow-400 mr-3 shrink-0 mt-1" />
                <div>
                  <h4 className="font-semibold text-purple-300">{t('common:nav.mining')}</h4>
                  <p className="text-gray-400">{t('welcomeModal.miningDesc')}</p>
                </div>
              </div>
              <div className="flex items-start p-3 bg-purple-500/10 rounded-lg border border-purple-500/30">
                <Users className="w-8 h-8 text-teal-400 mr-3 shrink-0 mt-1" />
                <div>
                  <h4 className="font-semibold text-purple-300">{t('common:nav.referral')}</h4>
                  <p className="text-gray-400">{t('welcomeModal.referralDesc')}</p>
                </div>
              </div>
              <div className="flex items-start p-3 bg-purple-500/10 rounded-lg border border-purple-500/30">
                <CheckSquare className="w-8 h-8 text-green-400 mr-3 shrink-0 mt-1" />
                <div>
                  <h4 className="font-semibold text-purple-300">{t('common:nav.tasks')}</h4>
                  <p className="text-gray-400">{t('welcomeModal.tasksDesc')}</p>
                </div>
              </div>
              <div className="flex items-start p-3 bg-purple-500/10 rounded-lg border border-purple-500/30">
                <Gamepad2 className="w-8 h-8 text-pink-400 mr-3 shrink-0 mt-1" />
                <div>
                  <h4 className="font-semibold text-purple-300">{t('common:nav.games')}</h4>
                  <p className="text-gray-400">{t('welcomeModal.gamesDesc')}</p>
                </div>
              </div>
            </motion.div>
            
            <DialogFooter className="mt-8">
              <Button 
                onClick={() => setIsOpen(false)} 
                className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-bold py-3 px-6 rounded-lg shadow-lg transition-all duration-300 transform hover:scale-105"
              >
                {t('welcomeModal.ctaButton')}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      );
    };

    export default WelcomeModal;