import React, { useState, useEffect, useRef } from 'react';
    import { useToast } from '@/components/ui/use-toast';
    import { motion } from 'framer-motion';
    import { useTonConnectUI, useTonWallet } from '@tonconnect/ui-react';
    import { supabase } from '@/lib/supabaseClient';
    import Wheel from './spinAndWin/subcomponents/Wheel';
    import TicketManager from './spinAndWin/subcomponents/TicketManager';
    import BuyTicketsModal from './spinAndWin/subcomponents/BuyTicketsModal';

    const TICKET_PRICE_TON = 0.1;
    const BOLTCOIN_TREASURY_WALLET = 'UQAqPFXgVhDpXe-WbJgfwVd_ETkmPMqEjLaNKLtDTKxVAJgk';

    const segments = [
      { type: 'bolt', value: 5, label: '5 $BOLT', color: '#f59e0b' },
      { type: 'ticket', value: 1, label: '1 Ticket', color: '#10b981' },
      { type: 'bolt', value: 10, label: '10 $BOLT', color: '#f59e0b' },
      { type: 'ton', value: 0.05, label: '0.05 TON', color: '#0098EA' },
      { type: 'bolt', value: 20, label: '20 $BOLT', color: '#f59e0b' },
      { type: 'ticket', value: 2, label: '2 Tickets', color: '#10b981' },
      { type: 'bolt', value: 50, label: '50 $BOLT', color: '#f59e0b' },
      { type: 'ton', value: 0.1, label: '0.1 TON', color: '#0098EA' },
    ];

    const SpinAndWinGame = ({ t, onGameEnd, updateBoltBalance, userProfile }) => {
      const { toast } = useToast();
      const [spinning, setSpinning] = useState(false);
      const [rotation, setRotation] = useState(0);
      const [tickets, setTickets] = useState(1); 
      const [isBuyTicketsModalOpen, setIsBuyTicketsModalOpen] = useState(false);
      const [buyAmount, setBuyAmount] = useState(1);
      const [tonBalance, setTonBalance] = useState(0); 
      const [isProcessingPayment, setIsProcessingPayment] = useState(false);

      const wallet = useTonWallet();
      const [tonConnectUI, setOptions] = useTonConnectUI();
      const wheelRef = useRef(null);

      useEffect(() => {
        const fetchTickets = async () => {
          if (userProfile?.id) {
            const { data, error } = await supabase
              .from('users')
              .select('spin_tickets')
              .eq('id', userProfile.id)
              .single();
            if (error) {
              console.error('Error fetching spin tickets:', error);
              setTickets(parseInt(localStorage.getItem('spinTicketsFallback') || '1'));
            } else if (data) {
              setTickets(data.spin_tickets !== null ? data.spin_tickets : 1);
            }
          } else {
             setTickets(parseInt(localStorage.getItem('spinTicketsFallback') || '1'));
          }
        };
        fetchTickets();
      }, [userProfile]);

      useEffect(() => {
        if (userProfile?.id && tickets !== null && tickets !== undefined) {
           localStorage.setItem('spinTicketsFallback', tickets.toString()); 
        }
      }, [tickets, userProfile]);


      useEffect(() => {
        const fetchTonBalance = async () => {
          if (wallet?.account?.balance) {
            setTonBalance(parseFloat(wallet.account.balance) / 1_000_000_000);
          } else {
            const storedWalletInfo = localStorage.getItem('tonWalletInfo');
            if (storedWalletInfo) {
                const parsedInfo = JSON.parse(storedWalletInfo);
                if (parsedInfo.balance) {
                    setTonBalance(parseFloat(parsedInfo.balance) / 1_000_000_000); 
                }
            }
          }
        };
        if (isBuyTicketsModalOpen && wallet) {
            fetchTonBalance();
        }
      }, [isBuyTicketsModalOpen, wallet]);

      useEffect(() => {
        if (tonConnectUI && isBuyTicketsModalOpen) {
          setOptions({
            actionsConfiguration: {
              twaReturnUrl: `https://t.me/BoltCoinDev_Bot/BoltCoinDevApp?from=buy_tickets`
            }
          });
        }
      }, [tonConnectUI, setOptions, isBuyTicketsModalOpen]);


      const handleSpin = async () => {
        if (tickets < 1) {
          toast({ title: t('games:spinAndWin.noTickets'), variant: 'destructive' });
          return;
        }
        if (spinning) return;

        setSpinning(true);
        const newTicketCount = tickets - 1;
        setTickets(newTicketCount);

        if (userProfile?.id) {
          const { error } = await supabase
            .from('users')
            .update({ spin_tickets: newTicketCount })
            .eq('id', userProfile.id);
          if (error) console.error("Error updating tickets in DB after spin:", error);
        }


        const randomSpins = Math.floor(Math.random() * 5) + 5; 
        const targetSegmentIndex = Math.floor(Math.random() * segments.length);
        const segmentAngle = 360 / segments.length;
        const targetRotation = (randomSpins * 360) + (targetSegmentIndex * segmentAngle) - (segmentAngle / 2) + (Math.random() * segmentAngle * 0.8 - segmentAngle * 0.4);
        
        setRotation(prevRotation => prevRotation - targetRotation); 

        setTimeout(async () => {
          const winningSegment = segments[targetSegmentIndex];
          setSpinning(false);

          let rewardMessage = '';
          if (winningSegment.type === 'bolt') {
            updateBoltBalance(winningSegment.value);
            rewardMessage = t('games:spinAndWin.wonMessage', { prize: `${winningSegment.value} $BOLT` });
          } else if (winningSegment.type === 'ticket') {
            const updatedTicketsAfterWin = newTicketCount + winningSegment.value;
            setTickets(updatedTicketsAfterWin);
            if (userProfile?.id) {
              const { error } = await supabase
                .from('users')
                .update({ spin_tickets: updatedTicketsAfterWin })
                .eq('id', userProfile.id);
              if (error) console.error("Error updating tickets in DB after win:", error);
            }
            rewardMessage = t('games:spinAndWin.wonMessage', { prize: `${winningSegment.value} Ticket(s)` });
          } else if (winningSegment.type === 'ton') {
            rewardMessage = t('games:spinAndWin.wonMessage', { prize: `${winningSegment.value} TON` });
            toast({ title: t('common:toast.comingSoon'), description: t('games:spinAndWin.tonWinSoon'), variant: 'info' });
          }
          
          if (onGameEnd) {
            onGameEnd(0, { reward: winningSegment.label }); 
          }

          toast({
            title: t('games:spinAndWin.congratsTitle'),
            description: rewardMessage,
          });
        }, 5000); 
      };

      const handleBuyTickets = async () => {
        if (!wallet) {
          toast({ title: t('wallet:notConnected'), description: t('wallet:connectToProceed'), variant: 'destructive' });
          if (tonConnectUI) tonConnectUI.openModal();
          return;
        }

        const totalCost = buyAmount * TICKET_PRICE_TON;
        if (tonBalance < totalCost) {
          toast({ title: t('games:spinAndWin.buyTicketsModal.purchaseError'), description: t('games:spinAndWin.buyTicketsModal.insufficientTon'), variant: 'destructive' });
          return;
        }
        
        setIsProcessingPayment(true);
        const payloadComment = `buy_spin_tickets_${buyAmount}_user_${userProfile?.id || 'unknown_user'}`;
        
        const transaction = {
          validUntil: Math.floor(Date.now() / 1000) + 600, 
          messages: [
            {
              address: BOLTCOIN_TREASURY_WALLET,
              amount: (totalCost * 1_000_000_000).toString(), 
              payload: Buffer.from(payloadComment).toString('base64')
            },
          ],
        };

        try {
          toast({
            title: t('games:spinAndWin.buyTicketsModal.processingPaymentTitle'),
            description: t('games:spinAndWin.buyTicketsModal.processingPaymentDescription', { amount: buyAmount, cost: totalCost.toFixed(2) }),
          });
          const result = await tonConnectUI.sendTransaction(transaction);
          
          const boc = result.boc; 

          const newTotalTickets = tickets + buyAmount;
          setTickets(newTotalTickets);
          toast({ title: t('games:spinAndWin.buyTicketsModal.purchaseSuccessTitle'), description: t('games:spinAndWin.buyTicketsModal.purchaseSuccessDescription', { amount: buyAmount }), variant: 'success' });
          
          if (userProfile?.id) {
            const { error: dbError } = await supabase
              .from('users')
              .update({ spin_tickets: newTotalTickets })
              .eq('id', userProfile.id);
            if (dbError) {
                console.error('Error updating spin tickets in DB:', dbError);
                toast({ title: t('common:toast.errorTitle'), description: t('common:toastMessages.databaseError'), variant: 'destructive'});
            }
          }
          
        } catch (error) {
          console.error('TON Transaction Error for buying tickets:', error);
            let errorMessage = t('mining:transactionFailed');
            if (error && typeof error === 'object' && 'message' in error) {
                errorMessage = error.message;
                if (error.message.toLowerCase().includes('user rejected') || error.message.toLowerCase().includes('user declined')) {
                    errorMessage = t('common:toastMessages.userRejectedTransaction');
                } else if (error.message.toLowerCase().includes('insufficient funds') || error.message.toLowerCase().includes('not enough balance')) {
                    errorMessage = t('common:toastMessages.insufficientTonBalance');
                } else if (error.message.toLowerCase().includes("popup_closed") || error.message.toLowerCase().includes("window was closed")) {
                    errorMessage = t('common:toastMessages.popupClosed', {ns: 'common'});
                } else if (error.message.toLowerCase().includes("timeout") || error.message.toLowerCase().includes("expired")) {
                    errorMessage = t('common:toastMessages.transactionExpired', {ns: 'common'});
                }
            } else if (typeof error === 'string') {
                errorMessage = error;
            }
          toast({ title: t('games:spinAndWin.buyTicketsModal.purchaseError'), description: errorMessage, variant: 'destructive' });
        } finally {
          setIsProcessingPayment(false);
          setIsBuyTicketsModalOpen(false);
        }
      };

      return (
        <div className="flex flex-col items-center justify-center p-2 sm:p-4 h-full text-white">
          <motion.h2 
            className="text-xl sm:text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 via-pink-500 to-purple-500 mb-4 sm:mb-6"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            {t('games:spinAndWin.gameTitle')}
          </motion.h2>

          <Wheel segments={segments} rotation={rotation} wheelRef={wheelRef} />
          
          <TicketManager 
            t={t} 
            tickets={tickets} 
            onSpin={handleSpin} 
            spinning={spinning} 
            onBuyTickets={() => setIsBuyTicketsModalOpen(true)} 
          />
          
          <BuyTicketsModal
            t={t}
            isOpen={isBuyTicketsModalOpen}
            onClose={() => setIsBuyTicketsModalOpen(false)}
            tonBalance={tonBalance}
            buyAmount={buyAmount}
            setBuyAmount={setBuyAmount}
            onConfirmBuy={handleBuyTickets}
            isProcessingPayment={isProcessingPayment}
          />
        </div>
      );
    };

    export default SpinAndWinGame;