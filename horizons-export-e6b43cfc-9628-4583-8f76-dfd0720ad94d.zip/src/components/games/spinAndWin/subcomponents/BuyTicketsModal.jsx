import React from 'react';
    import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Loader2 } from 'lucide-react';

    const TICKET_PRICE_TON = 0.1;

    const BuyTicketsModal = ({ 
      t, 
      isOpen, 
      onClose, 
      tonBalance, 
      buyAmount, 
      setBuyAmount, 
      onConfirmBuy, 
      isProcessingPayment 
    }) => {
      return (
        <Dialog open={isOpen} onOpenChange={onClose}>
          <DialogContent className="sm:max-w-md bg-gradient-to-br from-gray-800 via-purple-900 to-gray-800 border-purple-500/50 text-white">
            <DialogHeader>
              <DialogTitle className="text-lg sm:text-xl text-purple-300">{t('gamesPage.spinAndWin.buyTicketsModal.title')}</DialogTitle>
              <DialogDescription className="text-xs sm:text-sm text-gray-400">
                {t('gamesPage.spinAndWin.buyTicketsModal.description')}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-3 sm:space-y-4 py-2">
              <p className="text-sm text-cyan-300">{t('gamesPage.spinAndWin.buyTicketsModal.tonBalance', { balance: tonBalance.toFixed(4) })}</p>
              <p className="text-sm text-yellow-400">{t('gamesPage.spinAndWin.buyTicketsModal.ticketPrice')}</p>
              
              <div>
                <label htmlFor="buyAmount" className="block text-xs font-medium text-purple-300 mb-1">{t('gamesPage.spinAndWin.buyTicketsModal.quantity')}</label>
                <Input 
                  id="buyAmount"
                  type="number" 
                  value={buyAmount} 
                  onChange={(e) => setBuyAmount(Math.max(1, parseInt(e.target.value) || 1))}
                  min="1"
                  className="bg-gray-700/50 border-purple-600 text-gray-200 focus:ring-yellow-500 text-sm h-9 sm:h-10"
                />
              </div>
              <p className="text-sm font-semibold text-yellow-400">{t('gamesPage.spinAndWin.buyTicketsModal.totalCost', { cost: (buyAmount * TICKET_PRICE_TON).toFixed(2) })}</p>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={onClose} className="border-gray-500 text-gray-300 hover:bg-gray-700 text-sm sm:text-base">
                {t('adminPage.cancelButton')}
              </Button>
              <Button onClick={onConfirmBuy} disabled={isProcessingPayment} className="bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-white font-bold text-sm sm:text-base">
                {isProcessingPayment ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                {isProcessingPayment ? t('walletPage.processingPayment') : t('gamesPage.spinAndWin.buyTicketsModal.buyButton')}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      );
    };
    export default BuyTicketsModal;