import React, { useState, useEffect } from 'react';
    import { Button } from '@/components/ui/button';
    import { Zap, Clock, Image as ImageIcon, ShoppingCart, Loader2 } from 'lucide-react';
    import { motion } from 'framer-motion';
    import { useToast } from '@/components/ui/use-toast';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
    import { useTonConnectUI, useTonWallet } from '@tonconnect/ui-react';
    import { useTranslation } from 'react-i18next';
    
    const BOLTCOIN_TREASURY_WALLET = 'UQAqPFXgVhDpXe-WbJgfwVd_ETkmPMqEjLaNKLtDTKxVAJgk';

    const UpgradeCard = ({ item, onPurchase, itemType, currentBalance, currentMiningRateMultiplier, userProfile }) => {
      const { t } = useTranslation(['mining', 'common', 'wallet']);
      const { toast } = useToast();
      const wallet = useTonWallet();
      const [tonConnectUI, setOptions] = useTonConnectUI();
      const [isProcessingPayment, setIsProcessingPayment] = useState(false);
      const [tonBalance, setTonBalance] = useState(0);

      useEffect(() => {
        const fetchTonBalance = async () => {
          if (wallet?.account?.balance) {
            setTonBalance(parseFloat(wallet.account.balance) / 1_000_000_000);
          } else {
            const storedWalletInfo = localStorage.getItem('tonWalletInfo');
            if (storedWalletInfo) {
                const parsedInfo = JSON.parse(storedWalletInfo);
                if (parsedInfo.balance) {
                    setTonBalance(parseFloat(parsedInfo.balance) / 1_000_000_000); 
                }
            }
          }
        };
        if (wallet) {
            fetchTonBalance();
        }
      }, [wallet]);
      
      useEffect(() => {
        if (tonConnectUI) {
          setOptions({
            actionsConfiguration: {
              twaReturnUrl: `https://t.me/BoltCoinDev_Bot/BoltCoinDevApp?from=purchase_${itemType}_${item.id || item.labelKey}`
            }
          });
        }
      }, [tonConnectUI, setOptions, itemType, item.id, item.labelKey]);


      const isBoltPurchase = item.costBolt !== undefined && currentBalance >= item.costBolt;
      const isTonPurchase = item.costTon !== undefined && wallet && tonBalance >= item.costTon;
      
      const isPurchasable = isBoltPurchase || isTonPurchase;
      const isSpeedUpgradeAlreadyMax = itemType === 'speed' && currentMiningRateMultiplier >= item.multiplier;


      const handlePurchaseClick = async () => {
        if (isSpeedUpgradeAlreadyMax && itemType === 'speed') {
           toast({ title: t('upgradesModal.alreadyPurchased', { ns: 'mining' }), description: t('upgradesModal.speedAlreadyMax', { ns: 'mining' }), variant: "warning" });
           return;
        }

        if (!isPurchasable && item.costTon !== undefined) {
          if (!wallet) {
            toast({ title: t('notConnected', { ns: 'wallet' }), description: t('connectToProceed', { ns: 'wallet' }), variant: 'destructive' });
            if (tonConnectUI) tonConnectUI.openModal();
          } else if (tonBalance < item.costTon) {
            toast({ title: t('upgradesModal.insufficientFunds.title', { ns: 'mining' }), description: t('upgradesModal.insufficientFunds.descriptionTon', { ns: 'mining' }), variant: "destructive" });
          }
          return;
        }

        if (!isPurchasable && item.costBolt !== undefined) {
           if (currentBalance < item.costBolt) {
            toast({ title: t('upgradesModal.insufficientFunds.title', { ns: 'mining' }), description: t('upgradesModal.insufficientFunds.descriptionBolt', { ns: 'mining' }), variant: "destructive" });
          }
          return;
        }
        
        setIsProcessingPayment(true);

        if (item.costTon !== undefined) { 
          if (!wallet) {
            toast({ title: t('notConnected', { ns: 'wallet' }), description: t('connectToProceed', { ns: 'wallet' }), variant: 'destructive' });
            if (tonConnectUI) tonConnectUI.openModal();
            setIsProcessingPayment(false);
            return;
          }
          
          const payloadComment = `purchase_${itemType}_${item.id || item.labelKey}_user_${userProfile?.id || 'unknown_user'}`;
          
          const transaction = {
            validUntil: Math.floor(Date.now() / 1000) + 600, 
            messages: [
              {
                address: BOLTCOIN_TREASURY_WALLET,
                amount: (item.costTon * 1_000_000_000).toString(), 
                payload: Buffer.from(payloadComment).toString('base64')
              },
            ],
          };

          try {
            toast({
              title: t('upgradesModal.processingTonPayment.title', { ns: 'mining' }),
              description: t('upgradesModal.processingTonPayment.description', { ns: 'mining', item: t(item.labelKey, { ns: 'mining' }), cost: item.costTon }),
            });
            const result = await tonConnectUI.sendTransaction(transaction);
            
            const boc = result.boc; 
            
            onPurchase(itemType, item, item.costTon, 'TON', boc); 
          } catch (error) {
            console.error('TON Transaction Error for upgrade:', error);
            let errorMessage = t('transactionFailed', { ns: 'mining' });
            if (error && typeof error === 'object' && 'message' in error) {
                errorMessage = error.message;
                if (error.message.toLowerCase().includes('user rejected') || error.message.toLowerCase().includes('user declined')) {
                    errorMessage = t('toastMessages.userRejectedTransaction', { ns: 'common' });
                } else if (error.message.toLowerCase().includes('insufficient funds') || error.message.toLowerCase().includes('not enough balance')) {
                    errorMessage = t('toastMessages.insufficientTonBalance', { ns: 'common' });
                } else if (error.message.toLowerCase().includes("popup_closed") || error.message.toLowerCase().includes("window was closed")) {
                    errorMessage = t('toastMessages.popupClosed', {ns: 'common'});
                } else if (error.message.toLowerCase().includes("timeout") || error.message.toLowerCase().includes("expired")) {
                    errorMessage = t('toastMessages.transactionExpired', {ns: 'common'});
                }
            } else if (typeof error === 'string') {
                errorMessage = error;
            }
            toast({ title: t('purchaseError.title', { ns: 'mining' }), description: errorMessage, variant: 'destructive' });
          } finally {
            setIsProcessingPayment(false);
          }

        } else if (item.costBolt !== undefined) { 
            onPurchase(itemType, item, item.costBolt, '$BOLT', null);
            setIsProcessingPayment(false);
        }
      };

      const costDisplay = item.costTon !== undefined ? `${item.costTon} TON` : `${item.costBolt.toFixed(0)} $BOLT`;

      return (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.2 }}
          className="w-full"
        >
          <Card className={`shadow-md transition-all duration-300 ${isSpeedUpgradeAlreadyMax && itemType === 'speed' ? 'bg-green-800/40 border-green-600/60' : 'bg-gray-700/40 border-purple-600/60 hover:border-purple-500'}`}>
            <CardHeader className="pb-2 pt-3 sm:pb-3 sm:pt-4 px-3 sm:px-4">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm sm:text-base text-purple-300">{t(item.labelKey, { ns: 'mining' })}</CardTitle>
                {itemType === 'speed' && item.icon && <Zap className="h-4 w-4 sm:h-5 sm:w-5 text-yellow-400" />}
                {itemType === 'autoMining' && item.icon && <Clock className="h-4 w-4 sm:h-5 sm:w-5 text-blue-400" />}
                {itemType === 'background' && item.icon && <ImageIcon className="h-4 w-4 sm:h-5 sm:w-5 text-pink-400" />}
              </div>
            </CardHeader>
            <CardContent className="pb-3 sm:pb-4 px-3 sm:px-4">
              <CardDescription className="text-xs sm:text-sm text-gray-400 mb-1.5 sm:mb-2 min-h-[2.5em]">
                 {itemType === 'speed' && t('upgradesModal.speedDescription', { ns: 'mining', multiplier: item.multiplier })}
                 {itemType === 'autoMining' && t('upgradesModal.autoMiningDescription', { ns: 'mining', duration: item.durationDays })}
                 {itemType === 'background' && t(item.descriptionKey, { ns: 'mining' })}
              </CardDescription>
              <Button
                onClick={handlePurchaseClick}
                disabled={isProcessingPayment || !isPurchasable || (isSpeedUpgradeAlreadyMax && itemType === 'speed')}
                className={`w-full text-xs sm:text-sm py-1 sm:py-1.5 h-auto ${
                  isSpeedUpgradeAlreadyMax && itemType === 'speed'
                    ? 'bg-green-600 hover:bg-green-700 cursor-not-allowed'
                    : isPurchasable
                    ? 'bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-white'
                    : 'bg-gray-500 text-gray-300 cursor-not-allowed'
                }`}
              >
                {isProcessingPayment ? <Loader2 className="mr-1 sm:mr-1.5 h-3 w-3 sm:h-3.5 sm:w-3.5 animate-spin" /> : <ShoppingCart className="mr-1 sm:mr-1.5 h-3 w-3 sm:h-3.5 sm:w-3.5" />}
                {isSpeedUpgradeAlreadyMax && itemType === 'speed' ? t('upgradesModal.purchased', { ns: 'mining' }) : costDisplay}
              </Button>
            </CardContent>
          </Card>
        </motion.div>
      );
    };
    
    export default UpgradeCard;