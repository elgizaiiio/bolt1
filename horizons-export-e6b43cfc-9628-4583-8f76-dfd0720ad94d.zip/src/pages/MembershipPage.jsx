import React, { useState, useEffect } from 'react';
    import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
    import { Button } from '@/components/ui/button';
    import { Crown, Zap, Users, CheckSquare, Gamepad2, ShieldCheck, Loader2 } from 'lucide-react';
    import { motion } from 'framer-motion';
    import { useTranslation } from 'react-i18next';
    import { useToast } from '@/components/ui/use-toast';
    import { useTonConnectUI, useTonWallet } from '@tonconnect/ui-react';
    import { supabase } from '@/lib/supabaseClient';

    const membershipTiersData = [
      {
        id: 'bronze',
        nameKey: 'membership:bronze.name',
        price: 0.5, 
        color: 'text-orange-400',
        borderColor: 'border-orange-500/50',
        bgColor: 'bg-orange-500/10',
        buttonGradient: 'from-orange-500 to-yellow-500',
        features: [
          { textKey: 'membership:bronze.feature1', icon: Zap },
          { textKey: 'membership:bronze.feature2', icon: CheckSquare },
          { textKey: 'membership:bronze.feature3', icon: Users },
          { textKey: 'membership:bronze.feature4', icon: Gamepad2 },
        ],
        miningBonus: 0.1,
        taskBonus: 0.1,
        referralBonus: 0.1,
        dailySpinTickets: 1,
      },
      {
        id: 'silver',
        nameKey: 'membership:silver.name',
        price: 1, 
        color: 'text-slate-400',
        borderColor: 'border-slate-500/50',
        bgColor: 'bg-slate-500/10',
        buttonGradient: 'from-slate-500 to-gray-500',
        features: [
          { textKey: 'membership:silver.feature1', icon: Zap },
          { textKey: 'membership:silver.feature2', icon: CheckSquare },
          { textKey: 'membership:silver.feature3', icon: Users },
          { textKey: 'membership:silver.feature4', icon: Gamepad2 },
        ],
        miningBonus: 0.25,
        taskBonus: 0.25,
        referralBonus: 0.25,
        dailySpinTickets: 2,
      },
      {
        id: 'gold',
        nameKey: 'membership:gold.name',
        price: 2.5, 
        color: 'text-yellow-400',
        borderColor: 'border-yellow-500/50',
        bgColor: 'bg-yellow-500/10',
        buttonGradient: 'from-yellow-500 to-amber-500',
        features: [
          { textKey: 'membership:gold.feature1', icon: Zap },
          { textKey: 'membership:gold.feature2', icon: CheckSquare },
          { textKey: 'membership:gold.feature3', icon: Users },
          { textKey: 'membership:gold.feature4', icon: Gamepad2 },
          { textKey: 'membership:gold.feature5', icon: ShieldCheck },
        ],
        miningBonus: 0.5,
        taskBonus: 0.5,
        referralBonus: 0.5,
        dailySpinTickets: 5,
      },
    ];
    
    const BOLTCOIN_TREASURY_WALLET = 'UQAqPFXgVhDpXe-WbJgfwVd_ETkmPMqEjLaNKLtDTKxVAJgk';

    const MembershipPage = ({ updateUserMembership, userProfile }) => {
      const { t } = useTranslation(['membership', 'wallet', 'common']);
      const { toast } = useToast();
      const [currentMembershipId, setCurrentMembershipId] = useState(null);
      const [processingPayment, setProcessingPayment] = useState(null); 
      const wallet = useTonWallet();
      const [tonConnectUI, setOptions] = useTonConnectUI();

      useEffect(() => {
        if (userProfile?.membership_tier) {
          setCurrentMembershipId(userProfile.membership_tier);
        } else {
          const storedMembership = localStorage.getItem('userMembership');
          if (storedMembership) {
            const parsedMembership = JSON.parse(storedMembership);
            setCurrentMembershipId(parsedMembership.id);
          }
        }
      }, [userProfile]);
      
      useEffect(() => {
        if (tonConnectUI) {
          setOptions({
            actionsConfiguration: {
              twaReturnUrl: 'https://t.me/BoltCoinDev_Bot/BoltCoinDevApp?from=membership_purchase'
            }
          });
        }
      }, [tonConnectUI, setOptions]);

      const handleSubscribe = async (tier) => {
        if (!wallet) {
          toast({
            title: t('wallet:notConnected'),
            description: t('wallet:connectToProceed'),
            variant: 'destructive',
          });
          if (tonConnectUI) tonConnectUI.openModal();
          return;
        }

        setProcessingPayment(tier.id);
        const payloadComment = `subscribe_membership_${tier.id}_user_${userProfile?.id || 'unknown_user'}`;

        const transaction = {
          validUntil: Math.floor(Date.now() / 1000) + 600, 
          messages: [
            {
              address: BOLTCOIN_TREASURY_WALLET,
              amount: (tier.price * 1_000_000_000).toString(), 
              payload: Buffer.from(payloadComment).toString('base64') 
            },
          ],
        };

        try {
          toast({
            title: t('purchaseToast.title', { tierName: t(tier.nameKey) }),
            description: t('purchaseToast.description', { price: tier.price }),
          });

          const result = await tonConnectUI.sendTransaction(transaction);
          
          const boc = result.boc;

          toast({
            title: t('activationSuccess'),
            description: t('enjoyBenefits', { tierName: t(tier.nameKey) }),
            variant: 'success',
          });
          
          updateUserMembership(tier); 
          setCurrentMembershipId(tier.id);
          localStorage.setItem('userMembership', JSON.stringify(tier));

          if (userProfile?.id) {
            const { error: dbError } = await supabase
              .from('users')
              .update({ 
                membership_tier: tier.id, 
                membership_expires_at: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString() 
              }) 
              .eq('id', userProfile.id);
            if (dbError) {
              console.error('Error updating user membership in DB:', dbError);
              toast({ title: t('common:toast.errorTitle'), description: t('dbUpdateError'), variant: 'destructive' });
            }
          }

        } catch (error) {
          console.error('TON Transaction Error for membership:', error);
            let errorMessage = t('transactionFailed');
            if (error && typeof error === 'object' && 'message' in error) {
                errorMessage = error.message;
                if (error.message.toLowerCase().includes('user rejected') || error.message.toLowerCase().includes('user declined')) {
                    errorMessage = t('common:toastMessages.userRejectedTransaction');
                } else if (error.message.toLowerCase().includes('insufficient funds') || error.message.toLowerCase().includes('not enough balance')) {
                    errorMessage = t('common:toastMessages.insufficientTonBalance');
                } else if (error.message.toLowerCase().includes("popup_closed") || error.message.toLowerCase().includes("window was closed")) {
                    errorMessage = t('common:toastMessages.popupClosed', {ns: 'common'});
                } else if (error.message.toLowerCase().includes("timeout") || error.message.toLowerCase().includes("expired")) {
                    errorMessage = t('common:toastMessages.transactionExpired', {ns: 'common'});
                }
            } else if (typeof error === 'string') {
                errorMessage = error;
            }
          toast({
            title: t('activationError'),
            description: errorMessage,
            variant: 'destructive',
          });
        } finally {
          setProcessingPayment(null);
        }
      };

      return (
        <div className="py-8 sm:py-10">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center mb-8 sm:mb-12"
          >
            <Crown className="mx-auto h-12 w-12 sm:h-16 sm:w-16 text-yellow-400 mb-3 sm:mb-4 animate-pulse" />
            <h1 className="text-3xl sm:text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-pink-500 to-yellow-500 px-2">
              {t('mainTitle')}
            </h1>
            <p className="text-base sm:text-lg text-purple-300 mt-1 sm:mt-2 px-2">
              {t('mainDescription')}
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
            {membershipTiersData.map((tier, index) => (
              <motion.div
                key={tier.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
                className="flex"
              >
                <Card className={`shadow-lg hover:shadow-xl transition-all duration-300 ${tier.bgColor} ${tier.borderColor} overflow-hidden flex flex-col h-full w-full transform hover:-translate-y-1`}>
                  <CardHeader className="p-5 sm:p-6 text-center">
                    <Crown className={`mx-auto h-10 w-10 sm:h-12 sm:w-12 mb-2 sm:mb-3 ${tier.color}`} />
                    <CardTitle className={`text-2xl sm:text-3xl font-bold ${tier.color}`}>{t(tier.nameKey)}</CardTitle>
                    <CardDescription className="text-lg sm:text-xl font-semibold text-gray-300 mt-1">
                      {tier.price} TON / {t('month')}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="p-5 sm:p-6 space-y-3 sm:space-y-4 flex-grow">
                    <ul className="space-y-2 sm:space-y-3">
                      {tier.features.map((feature, fIndex) => (
                        <li key={fIndex} className="flex items-center text-sm sm:text-base text-gray-300">
                          <feature.icon className={`w-4 h-4 sm:w-5 sm:h-5 mr-2 sm:mr-3 ${tier.color}`} />
                          {t(feature.textKey)}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                  <CardFooter className="p-5 sm:p-6 mt-auto">
                    <Button 
                      onClick={() => handleSubscribe(tier)}
                      disabled={currentMembershipId === tier.id || processingPayment === tier.id}
                      className={`w-full font-bold text-base sm:text-lg py-2.5 sm:py-3 shadow-md hover:shadow-lg transition-all duration-200 bg-gradient-to-r ${tier.buttonGradient} text-white disabled:opacity-70 disabled:cursor-not-allowed`}
                    >
                      {processingPayment === tier.id ? (
                        <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                      ) : null}
                      {currentMembershipId === tier.id ? t('subscribedButton') : (processingPayment === tier.id ? t('wallet:processingPayment') : t('subscribeButton'))}
                    </Button>
                  </CardFooter>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      );
    };

    export default MembershipPage;