import React, { useState, useEffect } from 'react';
    import { Button } from '@/components/ui/button';
    import { Wallet, CheckCircle, LogOut } from 'lucide-react';
    import { motion } from 'framer-motion';
    import { useTranslation } from 'react-i18next';
    import { useToast } from '@/components/ui/use-toast';
    import { TonConnectButton, useTonConnectUI, useTonWallet } from '@tonconnect/ui-react';

    const WalletConnectPage = () => {
      const { t } = useTranslation(['wallet', 'common']);
      const { toast } = useToast();
      const wallet = useTonWallet();
      const [tonConnectUI, setOptions] = useTonConnectUI();
      const [isClient, setIsClient] = useState(false);

      useEffect(() => {
        setIsClient(true);
      }, []);
      
      useEffect(() => {
        if (tonConnectUI) {
            setOptions({
                actionsConfiguration: {
                    twaReturnUrl: 'https://t.me/BoltCoinDev_Bot/BoltCoinDevApp'
                }
            });
        }
      }, [tonConnectUI, setOptions]);


      const handleDisconnect = async () => {
        if (tonConnectUI && tonConnectUI.connected) {
            try {
                await tonConnectUI.disconnect();
                toast({
                    title: t('wallet:disconnectedToast.title'),
                    description: t('wallet:disconnectedToast.description'),
                });
            } catch (error) {
                console.error("Wallet disconnection error:", error);
                toast({
                    title: t('wallet:disconnectionErrorToast.title'),
                    description: error.message || t('wallet:disconnectionErrorToast.description'),
                    variant: 'destructive',
                });
            }
        }
      };

      return (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="flex flex-col items-center justify-center min-h-[calc(100vh-200px)] py-10 text-center"
        >
          <Wallet className="w-16 h-16 sm:w-20 sm:h-20 text-yellow-400 mb-6 sm:mb-8 animate-bounce" />
          <h1 className="text-3xl sm:text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-pink-500 to-yellow-400 mb-4 sm:mb-6">
            {wallet ? t('wallet:connected') : t('wallet:title')}
          </h1>
          <p className="text-base sm:text-lg text-purple-300 mb-6 sm:mb-8 max-w-md px-4">
            {wallet ? t('wallet:manageConnection') : t('wallet:description')}
          </p>

          {isClient && (
            <div className="ton-connect-button-container">
              <TonConnectButton className="ton-connect-custom-button" />
            </div>
          )}

          {wallet && (
            <div className="mt-6 sm:mt-8 p-4 sm:p-6 bg-green-500/10 rounded-lg border border-green-500/30 text-center w-full max-w-md">
              <CheckCircle className="w-10 h-10 sm:w-12 sm:h-12 text-green-400 mx-auto mb-3 sm:mb-4" />
              <p className="text-lg sm:text-xl font-semibold text-green-300 mb-1 sm:mb-2">{t('wallet:walletConnectedSuccessfully')}</p>
              <p className="text-xs sm:text-sm text-gray-400 break-all px-2">
                {t('wallet:walletAddress')}: {wallet.account.address.slice(0, 6)}...{wallet.account.address.slice(-4)}
              </p>
              <Button
                onClick={handleDisconnect}
                variant="destructive"
                className="mt-4 sm:mt-5 text-xs sm:text-sm py-1.5 sm:py-2 px-3 sm:px-4"
              >
                <LogOut className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-1.5 sm:mr-2" />
                {t('wallet:disconnectButton')}
              </Button>
            </div>
          )}
          
          <p className="text-xs sm:text-sm text-gray-500 mt-8 sm:mt-12 max-w-md px-4">
            {t('wallet:supportedWallets')}
          </p>

          <style>{`
            .ton-connect-button-container div {
              width: auto; /* Allow the button to size naturally */
              margin: 0 auto; /* Center the button if it's not full width */
            }
            .ton-connect-custom-button button {
              background-image: linear-gradient(to right, #facc15, #fb923c) !important; /* yellow-500 to orange-500 */
              color: white !important;
              font-weight: bold !important;
              padding: 0.75rem 1.5rem !important; /* py-3 px-6 */
              border-radius: 0.5rem !important; /* rounded-lg */
              box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05) !important; /* shadow-xl */
              font-size: 1rem !important; /* text-lg */
              transition: all 0.3s ease !important;
              border: none !important;
            }
            .ton-connect-custom-button button:hover {
              background-image: linear-gradient(to right, #eab308, #f97316) !important; /* yellow-600 to orange-600 */
              transform: scale(1.05) !important;
            }
            .ton-connect-custom-button button:disabled {
              opacity: 0.7 !important;
              cursor: not-allowed !important;
              transform: none !important;
            }
            .tc-modal { /* Style for the connection modal */
              background-color: #1f2937 !important; /* gray-800 */
              border-radius: 0.75rem !important;
            }
            .tc-modal__header {
              color: #d1d5db !important; /* gray-300 */
            }
            .tc-connect-wallet__item {
               background-color: #374151 !important; /* gray-700 */
               border-radius: 0.5rem !important;
            }
            .tc-connect-wallet__item__name {
                color: #f3f4f6 !important; /* gray-100 */
            }
            .tc-connect-wallet__item:hover {
                 background-color: #4b5563 !important; /* gray-600 */
            }
          `}</style>
        </motion.div>
      );
    };

    export default WalletConnectPage;